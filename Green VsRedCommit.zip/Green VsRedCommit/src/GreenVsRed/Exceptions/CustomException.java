package GreenVsRed.Exceptions;

public class CustomException extends Throwable{

    private String message;

    public CustomException(String message) {
        super(message);

    }
}
