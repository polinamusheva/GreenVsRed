package GreenVsRed;

import GreenVsRed.Exceptions.CustomException;
import GreenVsRed.Interfaces.Grid;

import java.util.Arrays;
import java.util.Scanner;

//A class that reads input and validates data
public class InputReader {
    private int x;
    private int y;
    private final Scanner scanner = new Scanner(System.in);
    private int pointX;
    private int pointY;
    private int rotations;

    public Grid GenerateGrid() throws CustomException {

        int[] ints = parseInts(this.scanner.nextLine());
        validateGridDimensions(ints);

        Grid grid = new ArrayGrid(ints[0], ints[1]);
        this.x = ints[0];
        this.y = ints[1];

        int[][] data = new int[this.y][this.x];

        for (int i = 0; i < this.y; i++) {

            data[i] = validateGridInput(this.scanner.nextLine(), this.x);

        }

        return grid.fill(data);
    }

    public void readGameData() throws CustomException {

        int[] input = parseInts(scanner.nextLine());
        if (input.length != 3) {
            throw new CustomException("Invalid input");
        }
        if (!(0 <= input[0] && input[0] < this.x) || !(0 <= input[1] && input[1] < this.y)) {
            throw new CustomException("Point is out of grid bounds");
        }

        this.pointX = input[0];
        this.pointY = input[1];
        this.rotations = input[2];
    }

    public int getPointX() {
        return this.pointX;
    }

    public int getPointY() {
        return this.pointY;
    }

    public int getRotations() {
        return this.rotations;
    }

    private int[] parseInts(String input) {
        return Arrays.stream(input.split(",")).map(String::trim).mapToInt(Integer::parseInt).toArray();
    }

    private void validateGridDimensions(int[] ints) throws CustomException {
        if (ints.length != 2) {
            throw new CustomException("Invalid number of grid dimensions");
        }
        for (int anInt : ints) {
            if (anInt < 1) {
                throw new CustomException("Grid dimensions should start from 1");
            }
        }
    }

    private int[] validateGridInput(String input, int width) throws CustomException {

        int[] digits = Arrays.stream(input.split("")).filter(x -> !x.isBlank()).mapToInt(Integer::parseInt).toArray();

        if (digits.length != width) {
            throw new CustomException("Number of digits should be equal to the grid width");
        }
        for (int digit : digits) {
            if (digit != 0 && digit != 1) {
                throw new CustomException("Digits must be 0 or 1");
            }
        }
        return digits;
    }

}
