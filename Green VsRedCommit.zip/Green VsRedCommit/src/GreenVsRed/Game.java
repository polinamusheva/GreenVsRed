package GreenVsRed;

import GreenVsRed.Interfaces.Grid;
import GreenVsRed.Interfaces.Observer;

//A class that generates N new grid states (N is the given number of rotations) and notifies the observer
public class Game {

    private final Grid grid;
    private final int rotations;
    private final Observer observer;

    public Game(Grid generationZero, int rotations, Observer observer) {
        this.grid = generationZero;
        this.rotations = rotations;
        this.observer = observer;
    }

    public void Play() {
        Grid current = this.grid;
        for (int i = 0; i <= this.rotations; i++) {

            this.observer.Observe(current);

            current = Generator.Next(current);

        }

    }

}


