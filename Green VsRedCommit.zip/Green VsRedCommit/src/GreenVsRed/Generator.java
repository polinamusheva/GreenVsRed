package GreenVsRed;

import GreenVsRed.Interfaces.Grid;

//A class that generates the next grid generation
public class Generator {

    public static Grid Next(Grid grid) {

        Grid newGrid = new ArrayGrid(grid.getWidth(), grid.getHeight());

        for (int y = 0; y < grid.getHeight(); y++) {
            for (int x = 0; x < grid.getWidth(); x++) {
                Point current = new Point(x, y);

                switch (grid.getValueAt(x, y)) {
                    case 0 -> {
                        if (RedForSwitch(grid, current)) {
                            newGrid.setValueAt(x, y, 1);
                        } else {
                            newGrid.setValueAt(x, y, 0);
                        }
                    }
                    case 1 -> {
                        if (GreenForSwitch(grid, current)) {
                            newGrid.setValueAt(x, y, 0);
                        } else {
                            newGrid.setValueAt(x, y, 1);
                        }
                    }
                    default -> throw new IllegalStateException("Unexpected value: " + grid.getValueAt(x, y));
                }
            }

        }

        return newGrid;
    }

    private static boolean RedForSwitch(Grid grid, Point point) {
        boolean switchValue = false;
        int counter = 0;
        for (int y = point.getY() - 1; y <= point.getY() + 1; y++) {
            for (int x = point.getX() - 1; x <= point.getX() + 1; x++) {
                Point current = new Point(x, y);
                if (current.getX() == point.getX() && current.getY() == point.getY()) {
                    continue;
                }
                if (InRange(grid, current)) {
                    int valueAtCurrent = grid.getValueAt(current.getX(), current.getY());
                    if (valueAtCurrent == 1) {
                        counter++;
                    }
                }
            }
        }
        if (counter == 3 || counter == 6) {
            switchValue = true;
        }
        return switchValue;
    }

    private static boolean GreenForSwitch(Grid grid, Point point) {
        boolean switchValue = false;
        int counter = 0;
        for (int y = point.getY() - 1; y <= point.getY() + 1; y++) {
            for (int x = point.getX() - 1; x <= point.getX() + 1; x++) {
                Point current = new Point(x, y);
                if (current.getX() == point.getX() && current.getY() == point.getY()) {
                    continue;
                }
                if (InRange(grid, current)) {
                    int valueAtCurrent = grid.getValueAt(current.getX(), current.getY());
                    if (valueAtCurrent == 1) {
                        counter++;
                    }
                }
            }
        }
        if (counter == 0 || counter == 1 || counter == 4 || counter == 5 || counter == 7 || counter == 8) {
            switchValue = true;
        }
        return switchValue;
    }

    private static boolean InRange(Grid grid, Point point) {

        boolean inRange = false;

        int gridWidth = grid.getWidth();
        int gridHeight = grid.getHeight();

        int pointX = point.getX();
        int pointY = point.getY();

        if (0 <= pointX && pointX <= gridWidth - 1 && 0 <= pointY && pointY <= gridHeight - 1) {
            inRange = true;
        }
        return inRange;
    }


}
