package GreenVsRed;

import GreenVsRed.Interfaces.Grid;

//Implementation of the Grid interface
public class ArrayGrid implements Grid {

    private final int width;
    private final int height;


    private final int[][] grid;

    public ArrayGrid(int width, int height) {

        this.width = width;
        this.height = height;
        this.grid = new int[height][width];
    }

    private int[][] getGrid() {
        return this.grid;
    }

    @Override
    public int getWidth() {
        return this.width;
    }

    @Override
    public int getHeight() {
        return this.height;
    }

    @Override
    public Point getPoint(int x, int y) {
        return new Point(x, y);
    }

    @Override
    public Grid fill(int[][]data) {

        if (this.height >= 0) System.arraycopy(data, 0, this.getGrid(), 0, this.height);
        return this;
    }

    @Override
    public int getValueAt(int x, int y) {
        return this.getGrid()[y][x];
    }

    @Override
    public void setValueAt(int x, int y, int value) {
        this.getGrid()[y][x] = value;
    }
}
