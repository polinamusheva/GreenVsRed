package GreenVsRed;

import GreenVsRed.Interfaces.Grid;
import GreenVsRed.Interfaces.Observer;

//Observes if the point is green and counts the number of green states
public class GreenObserver implements Observer {

    private final Point point;
    private int counter;

    public GreenObserver(Point point) {
        this.point = point;
        this.counter = 0;
    }

    public int getCounter() {
        return this.counter;
    }

    @Override
    public void Observe(Grid grid) {
        int valueAt = grid.getValueAt(this.point.getX(), this.point.getY());
        if (valueAt == 1) {
            this.counter++;
        }

    }

}
