package GreenVsRed;

import GreenVsRed.Exceptions.CustomException;
import GreenVsRed.Interfaces.Grid;

public class Main {
    public static void main(String[] args) {

        InputReader reader = new InputReader();

        try {
            Grid generationZero = reader.GenerateGrid();

            reader.readGameData();

            Point observedPoint = new Point(reader.getPointX(), reader.getPointY());
            int rotations = reader.getRotations();

            GreenObserver observer = new GreenObserver(observedPoint);

            Game game = new Game(generationZero, rotations, observer);
            game.Play();

            System.out.println(observer.getCounter());

        } catch (CustomException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
