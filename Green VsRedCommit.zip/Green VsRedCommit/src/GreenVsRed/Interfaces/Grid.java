package GreenVsRed.Interfaces;

import GreenVsRed.Point;

//An interface representing the grid
public interface Grid {

    int getWidth();
    int getHeight();

    Point getPoint(int x, int y);

    Grid fill(int[][]data);

    int getValueAt(int x, int y);

    void setValueAt(int x, int y, int value);
}
