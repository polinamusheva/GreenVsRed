package GreenVsRed.Interfaces;

import GreenVsRed.Interfaces.Grid;

//Observes the state of a Point
public interface Observer {

    void Observe(Grid grid);

}
